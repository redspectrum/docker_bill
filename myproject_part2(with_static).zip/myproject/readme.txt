
From here:
https://ruddra.com/posts/docker-do-stuff-using-celery-using-redis-as-broker/


add static
docker exec DJANGOXDOCKERNAME /bin/sh -c "python manage.py collectstatic --noinput"
